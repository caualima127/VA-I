from django.contrib import admin
from .models import DetalheCurso

admin.site.register(DetalheCurso)
